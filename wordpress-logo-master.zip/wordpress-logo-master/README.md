# wordpress-logo
logo for equate dot create-wanting images for connections/connecting/syn.-connect2develop
